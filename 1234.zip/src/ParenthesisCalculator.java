package calculator;

import java.util.Stack;

/**
 *
 * @author alex
 */
public class ParenthesisCalculator extends PrecedenceCalculator {

    public ParenthesisCalculator(String title) {
        super(title);
    }

    public ParenthesisCalculator() {
        this("Calculator With Operator Precedence and Perenthesis Support");
    }

    @Override
    public void reduce() {
        int i;
        for (i = 0; i < getStack().size(); i++ ) {
                //System.out.println(getStack().get(i).toString()); }}
        while (getStack().size() != 1 ){
            for (i = 1; i < getStack().size(); i+=2 ) {
                System.out.println(getStack().get(i).toString());
                if (getStack().get(i).toString().equals("(")){
                    Stack<Object> rhsStack = new Stack<>();
                    for (int j = getStack().size()-1; j > i + 1; j--) rhsStack.push(getStack().pop());
                    getStack().pop();
                    for (int j = 0; j < rhsStack.size()-1; j++) getStack().push(rhsStack.pop());
                    continue;
                }
                if (getStack().get(i).toString().equals("*")) continue;
                if (getStack().get(i).toString().equals("/")) continue;
                if (getStack().get(i).toString().equals("+")) continue;
                if (getStack().get(i).toString().equals("-")) continue;
                else syntaxError(OP_OR_END);
                }
            reduceNumOpNum(i);
            }
        }
    }
}
    
