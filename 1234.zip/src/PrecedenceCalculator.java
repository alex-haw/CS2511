package calculator;

import java.util.Stack;

/**
 *
 * @author alex
 */
public class PrecedenceCalculator extends NoPrecedenceCalculator {

    public PrecedenceCalculator(String title) {
        super(title);
    }

    public PrecedenceCalculator() {
        this("Calculator With Operator Precedence");
    }

    @Override
    public void reduce() {
        int i;
        while (getStack().size() != 1 ){
            for (i = 1; i < getStack().size(); i+=2 ) {
                if (getStack().get(i).toString().equals("*")) continue;
                if (getStack().get(i).toString().equals("/")) continue;
                if (getStack().get(i).toString().equals("+")) continue;
                if (getStack().get(i).toString().equals("-")) continue;
                else syntaxError(OP_OR_END);
            }
            reduceNumOpNum(i);
        }
    }

    /**
     * Reduce NUM OP NUM at a specific operator index
     *
     * @param pos index of the operator to evaluate first
     */
    protected void reduceNumOpNum(int pos) {
            System.out.println(getStack().get(0).toString());
            if (pos == 1) reduceNumOpNum(); 
            else{
                Stack<Object> rhsStack = new Stack<>();
                for (int i = getStack().size(); i > pos + 1; i--) rhsStack.push(getStack().pop());
                reduceNumOpNum();
                for (int i = 0; i < rhsStack.size(); i++) getStack().push(rhsStack.pop());
            }
    }
    
    @Override
    protected void number() {
        shift();
        getDispenser().advance();
        if (getDispenser().tokenIsEOF()) {
            reduce();
            setState(State.END);
        } else if (getDispenser().tokenIsOperator()) {
            
            setState(State.OPERATOR);
        } else {
            syntaxError(OP_OR_END);
        }
    }
}
